This directory contains the official UEFI revocation databases, as provided by
https://github.com/microsoft/secureboot_objects/tree/main/PostSignedObjects.

These are used by Rufus to warn the user if a UEFI bootloader has been revoked.