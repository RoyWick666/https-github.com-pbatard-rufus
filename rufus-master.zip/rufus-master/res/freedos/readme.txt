All of the executables found in this repository where extracted from FreeDOS v1.4:
https://www.ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.4/FD14-FullUSB.zip

o COMMAND.COM was extracted from packages\base\freecom.zip
o DISPLAY.EXE was extracted from packages\base\display.zip
o The EGA[#].CPX files were extracted from packages\base\cpidos.zip
o KERNEL.SYS was taken from packages\base\kernel.zip (KERNL386.SYS)
  It was modified to have FORCELBA enabled (byte offset 0x0D set to 0x01)
o KEYB.EXE was extracted from packages\base\keyb.zip
o The KEYB###.SYS keyboard layouts were extracted from packages\base\keyb_lay.zip
o MODE.COM was extracted from packages\base\mode.zip
