o ldlinux_v4.[bss|sys] have been renamed from ldlinux.[bss|sys] found in syslinux-4.07/core/
o ldlinux_v6.[bss|sys] have been renamed from ldlinux.[bss|sys] found in syslinux-6.04-pre1/bios/core/
o mboot.c32 comes from syslinux-4.07/com32/mboot
  http://www.kernel.org/pub/linux/utils/boot/syslinux/